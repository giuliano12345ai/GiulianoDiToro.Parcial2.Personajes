package parcial2.giulianoditoro.colecciones;

import java.io.*;
import java.util.*;
import java.util.function.*;
import parcial2.giulianoditoro.interfaces.CSVSerializable;

public class ColeccionPersonajes<T extends CSVSerializable & Comparable<T>> implements Serializable {

    private final List<T> lista;

    public ColeccionPersonajes() {
        this.lista = new ArrayList<>();
    }

    public void agregar(T elemento) {
        lista.add(elemento);
    }

    public T obtener(int indice) {
        return lista.get(indice);
    }

    public void eliminar(int indice) {
        lista.remove(indice);
    }

    // Consumer para imprimir o procesar cada elemento
    public void paraCadaElemento(Consumer<T> accion) {
        lista.forEach(accion);
    }

    // Filtrado por lambda Predicate<T>
    public List<T> filtrar(Predicate<T> filtro) {
        List<T> resultado = new ArrayList<>();
        for (T elemento : lista) {
            if (filtro.test(elemento)) {
                resultado.add(elemento);
            }
        }
        return resultado;
    }

    // Orden natural (Comparable) o con Comparator externo
    public void ordenar(Comparator<T> comp) {
        lista.sort(comp);
    }

    public void ordenar() {
        Collections.sort(lista);
    }

    // Guardar y cargar desde archivo binario
    public void guardarEnArchivo(String ruta) throws IOException {
        try (ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream(ruta))) {
            oos.writeObject(lista);
        }
    }

    @SuppressWarnings("unchecked")
    public void cargarDesdeArchivo(String ruta) throws IOException, ClassNotFoundException {
        try (ObjectInputStream ois = new ObjectInputStream(new FileInputStream(ruta))) {
            List<T> cargada = (List<T>) ois.readObject();
            lista.clear();
            lista.addAll(cargada);
        }
    }

    // Guardar en CSV
    public void guardarEnCSV(String ruta) throws IOException {
        try (PrintWriter pw = new PrintWriter(new FileWriter(ruta))) {
            for (T elemento : lista) {
                pw.println(elemento.toCSV());
            }
        }
    }

    // Cargar desde CSV usando una lambda: linea -> Personaje.fromCSV(linea)
    public void cargarDesdeCSV(String ruta, Function<String, T> constructor) throws IOException {
        lista.clear();
        try (BufferedReader br = new BufferedReader(new FileReader(ruta))) {
            String linea;
            while ((linea = br.readLine()) != null) {
                lista.add(constructor.apply(linea));
            }
        }
    }
}
