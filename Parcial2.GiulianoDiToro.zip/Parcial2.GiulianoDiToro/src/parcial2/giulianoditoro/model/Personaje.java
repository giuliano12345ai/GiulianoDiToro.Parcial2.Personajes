package parcial2.giulianoditoro.model;

import java.io.Serializable;
import parcial2.giulianoditoro.interfaces.CSVSerializable;

public class Personaje implements Comparable<Personaje>, CSVSerializable, Serializable {

    private int id;
    private String nombre;
    private String creador;
    private RolPersonaje rol;

    public Personaje(int id, String nombre, String creador, RolPersonaje rol) {
        this.id = id;
        this.nombre = nombre;
        this.creador = creador;
        this.rol = rol;
    }

    public Personaje() {}

    public int getId() {
        return id;
    }

    public String getNombre() {
        return nombre;
    }

    public String getCreador() {
        return creador;
    }

    public RolPersonaje getRol() {
        return rol;
    }

    @Override
    public int compareTo(Personaje otro) {
        return Integer.compare(this.id, otro.id);
    }

    @Override
    public String toCSV() {
        return id + "," + nombre + "," + creador + "," + rol.name();
    }

    public static Personaje fromCSV(String linea) {
        String[] partes = linea.split(",");
        int id = Integer.parseInt(partes[0]);
        String nombre = partes[1];
        String creador = partes[2];
        RolPersonaje rol = RolPersonaje.valueOf(partes[3]);
        return new Personaje(id, nombre, creador, rol);
    }

    @Override
    public String toString() {
        return "ID: " + id + " - Nombre: " + nombre + " - Creador: " + creador + " - Rol: " + rol;
    }
}
