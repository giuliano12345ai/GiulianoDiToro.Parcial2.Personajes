package parcial2.giulianoditoro.interfaces;

public interface CSVSerializable {
    String toCSV();
}
